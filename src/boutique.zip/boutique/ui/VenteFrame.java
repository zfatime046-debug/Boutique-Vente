/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boutique.ui;

import boutique.dao.ClientDao;
import boutique.dao.IClientDao;
import boutique.dao.IProduitDao;
import boutique.dao.IVenteDao;
import boutique.dao.ProduitDao;
import boutique.dao.VenteDao;
import boutique.entities.Client;
import boutique.entities.Produit;
import boutique.entities.Vente;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JButton; 
import javax.swing.JLabel;  
/**
 *
 * @author hp
 */
public class VenteFrame extends javax.swing.JFrame {
    private IVenteDao venteDao = new VenteDao();
    private IClientDao clientDao = new ClientDao();
    private IProduitDao produitDao = new ProduitDao();
    private JComboBox<String> comboCategorie;
    private JSpinner dateDebutSpinner;
    private JSpinner dateFinSpinner;
    private JButton btnFiltrer;
    private JButton btnReinitialiser;

    /**
     * Creates new form VenteFrame
     */
    public VenteFrame() {
        initComponents();
        
    JPanel mainPanel = new JPanel(new BorderLayout());
    
    mainPanel.add(createFilterPanel(), BorderLayout.NORTH);
    
    JPanel contentPanel = new JPanel(new BorderLayout());
    
    
    JPanel formulaireEtBoutons = new JPanel(new BorderLayout());
    formulaireEtBoutons.add(jPanel7, BorderLayout.CENTER);
    formulaireEtBoutons.add(jPanel8, BorderLayout.EAST);
    
    contentPanel.add(formulaireEtBoutons, BorderLayout.NORTH);
    contentPanel.add(jScrollPane3, BorderLayout.CENTER);
    
    mainPanel.add(contentPanel, BorderLayout.CENTER);
    
    jPanel6.removeAll();
    jPanel6.setLayout(new BorderLayout());
    jPanel6.add(mainPanel, BorderLayout.CENTER);
    
    // Rafraîchir
    jPanel6.revalidate();
    jPanel6.repaint();
    
        panelVentes.addChangeListener(e -> {
    if (panelVentes.getSelectedIndex() == 1) { 
        loadSuiviVentes();
    }
});
        setSize(1200, 700);
        setTitle("Gestion des Ventes");
        setLocationRelativeTo(null);

        loadClients();
        loadProduits();
        loadTableVentes();
        loadSuiviVentes();

    }
    private void initTableSuivi() {
    tableSuivi.setModel(new DefaultTableModel(
        new Object[]{"IdProduit", "Produit", "Total vendu"},
        0
    ));
}
private void refreshSuiviParProduit() {
    DefaultTableModel model = (DefaultTableModel) tableSuivi.getModel();
    model.setRowCount(0);

    try {
        List<Object[]> rows = venteDao.venteParProduit(); 
        for (Object[] r : rows) {
            model.addRow(r);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
    }
}


private void loadClients() {
    ComboClient.removeAllItems();
    List<Client> clients = clientDao.findAll();
    for (Client c : clients) {
        ComboClient.addItem(c.getIdClient() + " - " + c.getNom());
    }
}
private void loadProduits() {
    ComboProduit.removeAllItems();
    List<Produit> produits = produitDao.findAll();
    for (Produit p : produits) {
        ComboProduit.addItem(p.getIdProduit() + " - " + p.getLibelle());
    }
}
private void loadTableVentes() {
    DefaultTableModel model = (DefaultTableModel) tableVentes.getModel();
    model.setRowCount(0);

    List<Vente> ventes = venteDao.findAll();
    for (Vente v : ventes) {
        model.addRow(new Object[]{
            v.getIdVente(),
            v.getDateVente(),
            v.getIdClient(),
            v.getIdProduit(),
            v.getQuantite(),
            });
                    
    }
                }

private void loadSuiviVentes() {

    DefaultTableModel model = (DefaultTableModel) tableSuivi.getModel();
    model.setRowCount(0);

    for (Object[] row : venteDao.venteParProduit()) {
        model.addRow(row);
    }
}
private JPanel createFilterPanel() {
    JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
    filterPanel.setBorder(BorderFactory.createTitledBorder("Filtres"));
    
    // Catégorie
    filterPanel.add(new JLabel("Catégorie:"));
    comboCategorie = new JComboBox<>();
    comboCategorie.addItem("Toutes");
    
    // Remplir avec les catégories de la base
    VenteDao venteDao = new VenteDao();
    List<String> categories = venteDao.getAllCategories();
    for (String cat : categories) {
        comboCategorie.addItem(cat);
    }
    comboCategorie.setPreferredSize(new java.awt.Dimension(80, 25));
    filterPanel.add(comboCategorie);
    
    // Période
    filterPanel.add(new JLabel("Du:"));
    dateDebutSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor de = new JSpinner.DateEditor(dateDebutSpinner, "dd/MM/yyyy");
    dateDebutSpinner.setEditor(de);
    dateDebutSpinner.setValue(new Date()); // Date du jour par défaut
    dateDebutSpinner.setPreferredSize(new java.awt.Dimension(71, 25));
    filterPanel.add(dateDebutSpinner);
    
    filterPanel.add(new JLabel("Au:"));
    dateFinSpinner = new JSpinner(new SpinnerDateModel());
    JSpinner.DateEditor fe = new JSpinner.DateEditor(dateFinSpinner, "dd/MM/yyyy");
    dateFinSpinner.setEditor(fe);

    
    // Date par défaut 
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DAY_OF_MONTH, 30);
    dateFinSpinner.setValue(cal.getTime());
    dateFinSpinner.setPreferredSize(new java.awt.Dimension(71, 25));
    filterPanel.add(dateFinSpinner);
    filterPanel.add(new JLabel("   ")); 
    // Boutons
    btnFiltrer = new JButton("Filtrer");
    btnFiltrer.setPreferredSize(new java.awt.Dimension(70, 25));
    btnFiltrer.addActionListener(evt -> filtrerVentes());
    filterPanel.add(btnFiltrer);
    
    btnReinitialiser = new JButton("Réinitialiser");
    btnReinitialiser.setPreferredSize(new java.awt.Dimension(100, 25));
    btnReinitialiser.addActionListener(evt -> reinitialiserFiltres());
    filterPanel.add(btnReinitialiser);
    return filterPanel;
}

private void filtrerVentes() {
    String categorie = (String) comboCategorie.getSelectedItem();
    Date dateDebut = (Date) dateDebutSpinner.getValue();
    Date dateFin = (Date) dateFinSpinner.getValue();
    
    // Réinitialiser les heures pour inclure toute la journée
    Calendar calDebut = Calendar.getInstance();
    calDebut.setTime(dateDebut);
    calDebut.set(Calendar.HOUR_OF_DAY, 0);
    calDebut.set(Calendar.MINUTE, 0);
    calDebut.set(Calendar.SECOND, 0);
    calDebut.set(Calendar.MILLISECOND, 0);
    
    Calendar calFin = Calendar.getInstance();
    calFin.setTime(dateFin);
    calFin.set(Calendar.HOUR_OF_DAY, 23);
    calFin.set(Calendar.MINUTE, 59);
    calFin.set(Calendar.SECOND, 59);
    calFin.set(Calendar.MILLISECOND, 999);
    
    java.sql.Date sqlDateDebut = new java.sql.Date(dateDebut.getTime());
    java.sql.Date sqlDateFin = new java.sql.Date(dateFin.getTime());
    
    List<Vente> ventesFiltrees;
    VenteDao venteDao = new VenteDao();
    
      if (categorie.equals("Toutes")) {
        if (dateDebut != null && dateFin != null) {
            ventesFiltrees = venteDao.findByPeriode(sqlDateDebut, sqlDateFin);
        } else {
            ventesFiltrees = venteDao.findAll();
        }
    } else {
        if (dateDebut != null && dateFin != null) {
            ventesFiltrees = venteDao.findByCategorieAndPeriode(categorie, sqlDateDebut, sqlDateFin);
        } else {
            ventesFiltrees = venteDao.findByCategorie(categorie);
        }
    }
    
    // Mettre à jour l'affichage
    afficherVentesFiltrees(ventesFiltrees);
}

private void reinitialiserFiltres() {
    comboCategorie.setSelectedItem("Toutes");
    
    dateDebutSpinner.setValue(new Date());
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DAY_OF_MONTH, 30);
    dateFinSpinner.setValue(cal.getTime());
    
    // Recharger toutes les ventes
    loadTableVentes(); 
}

private void afficherVentesFiltrees(List<Vente> ventes) {
    DefaultTableModel model = (DefaultTableModel) tableVentes.getModel();
    model.setRowCount(0); // Vider la table
    
    for (Vente v : ventes) {
        String clientNom = "Client " + v.getIdClient();
        String produitNom = "Produit " + v.getIdProduit();
        
        try {
            Client c = clientDao.findById(v.getIdClient());
            if (c != null) clientNom = c.getNom();
            
            Produit p = produitDao.findById(v.getIdProduit());
            if (p != null) produitNom = p.getLibelle();
        } catch (Exception e) {
        }
        
        model.addRow(new Object[]{
            v.getIdVente(),
            v.getDateVente(),
            clientNom,      
            produitNom,     
            v.getQuantite()
        });
    }
}

    private int getIdFromCombo(javax.swing.JComboBox combo) {
    String s = combo.getSelectedItem().toString();
    return Integer.parseInt(s.split(" - ")[0]);
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        panelVentes = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        lblIdVente1 = new javax.swing.JLabel();
        lblClient1 = new javax.swing.JLabel();
        lblProduit1 = new javax.swing.JLabel();
        lblQuantite1 = new javax.swing.JLabel();
        txtIdVente = new javax.swing.JTextField();
        ComboClient = new javax.swing.JComboBox();
        ComboProduit = new javax.swing.JComboBox();
        txtQuantite = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDateVente = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        btnVendre1 = new javax.swing.JButton();
        btnSupprimer1 = new javax.swing.JButton();
        btnVider1 = new javax.swing.JButton();
        btnRetour1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableVentes = new javax.swing.JTable();
        panelSuivi = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableSuivi = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel7.setBackground(new java.awt.Color(255, 255, 204));

        lblIdVente1.setText("IdVente :");

        lblClient1.setText("Client :");

        lblProduit1.setText("Produit :");

        lblQuantite1.setText("Quantite :");

        txtIdVente.setEditable(false);

        jLabel4.setText("Formulaire :");

        jLabel5.setText("DateVnte:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(lblClient1)
                    .addComponent(lblProduit1)
                    .addComponent(lblQuantite1)
                    .addComponent(jLabel4)
                    .addComponent(lblIdVente1))
                .addGap(10, 10, 10)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(ComboClient, 0, 145, Short.MAX_VALUE)
                        .addComponent(ComboProduit, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtQuantite)
                        .addComponent(txtDateVente))
                    .addComponent(txtIdVente, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 97, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(40, 40, 40)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(lblIdVente1)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtDateVente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblClient1)
                            .addComponent(ComboClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblProduit1)
                            .addComponent(ComboProduit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtQuantite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblQuantite1))
                        .addGap(8, 8, 8))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(txtIdVente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 204));

        btnVendre1.setText("Vendre");
        btnVendre1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendre1ActionPerformed(evt);
            }
        });

        btnSupprimer1.setText("Supprimer");
        btnSupprimer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimer1ActionPerformed(evt);
            }
        });

        btnVider1.setText("Vider");
        btnVider1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVider1ActionPerformed(evt);
            }
        });

        btnRetour1.setText("Retour");
        btnRetour1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetour1ActionPerformed(evt);
            }
        });

        jLabel6.setText("Actions :");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSupprimer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnVendre1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnVider1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnRetour1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(btnVendre1)
                .addGap(28, 28, 28)
                .addComponent(btnSupprimer1)
                .addGap(30, 30, 30)
                .addComponent(btnVider1)
                .addGap(27, 27, 27)
                .addComponent(btnRetour1)
                .addContainerGap())
        );

        tableVentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "IdVente", "DateVente", "Client", "Produit", "Quantite"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableVentes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableVentesMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableVentes);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(194, Short.MAX_VALUE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 227, Short.MAX_VALUE)))
        );

        panelVentes.addTab("Ventes", jPanel6);

        tableSuivi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "IdProduit", "Libelle", "TotalVentes", "Nbr Ventes", "Prix Total "
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tableSuivi);

        jLabel1.setText("les ventes par produit :");

        javax.swing.GroupLayout panelSuiviLayout = new javax.swing.GroupLayout(panelSuivi);
        panelSuivi.setLayout(panelSuiviLayout);
        panelSuiviLayout.setHorizontalGroup(
            panelSuiviLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSuiviLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(panelSuiviLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        panelSuiviLayout.setVerticalGroup(
            panelSuiviLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSuiviLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(257, Short.MAX_VALUE))
        );

        panelVentes.addTab("Suivi par produit", panelSuivi);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelVentes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelVentes)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVendre1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendre1ActionPerformed
    
    try {
        if (ComboClient.getSelectedItem() == null || ComboProduit.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Choisissez un client et un produit !");
            return;
        }

        int idClient = getIdFromCombo(ComboClient);
        int idProduit = getIdFromCombo(ComboProduit);

        int qte = Integer.parseInt(txtQuantite.getText().trim());
        if (qte <= 0) {
            JOptionPane.showMessageDialog(this, "Quantité doit être > 0 !");
            return;
        }

        // 1) vérifier stock
        Produit p = produitDao.findById(idProduit);
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Produit introuvable !");
            return;
        }

        if (p.getStock() < qte) {
            JOptionPane.showMessageDialog(this,
                    "Stock insuffisant ! Stock actuel = " + p.getStock());
            return;
        }

        // 2) enregistrer vente
        Vente v = new Vente();
        v.setDateVente(new java.sql.Date(System.currentTimeMillis())); // date auto
        v.setIdClient(idClient);
        v.setIdProduit(idProduit);
        v.setQuantite(qte);

        venteDao.create(v);

        // 3) mise à jour stock
        p.setStock(p.getStock() - qte);
        produitDao.update(p);

        JOptionPane.showMessageDialog(this, "Vente enregistrée !");
        loadTableVentes();
        loadSuiviVentes();
        clearForm();         

        

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Quantité invalide !");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
        e.printStackTrace();
    }

    }//GEN-LAST:event_btnVendre1ActionPerformed

    private void btnSupprimer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimer1ActionPerformed
      if (txtIdVente.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, 
            "Veuillez sélectionner une vente à supprimer dans le tableau", 
            "Aucune sélection", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    // Demander confirmation
    int confirm = JOptionPane.showConfirmDialog(this,
        "Voulez-vous vraiment supprimer cette vente ?",
        "Confirmation de suppression",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);
    
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            int id = Integer.parseInt(txtIdVente.getText().trim());
            venteDao.delete(id);
            
            loadTableVentes();
            loadSuiviVentes();
            
            JOptionPane.showMessageDialog(this, 
                "Vente supprimée avec succès ✅", 
                "Succès", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur lors de la suppression: " + e.getMessage(),
                "Erreur", 
                JOptionPane.ERROR_MESSAGE);}
    }    
    }//GEN-LAST:event_btnSupprimer1ActionPerformed

    private void btnVider1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVider1ActionPerformed
              // Vérifier si le formulaire contient des données
    if (!txtIdVente.getText().trim().isEmpty() || 
        !txtQuantite.getText().trim().isEmpty() || 
        !txtDateVente.getText().trim().isEmpty()) {
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Voulez-vous vraiment vider le formulaire ?",
            "Confirmation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            clearForm();
            JOptionPane.showMessageDialog(this,
                "Formulaire vidé avec succès",
                "Information",
                JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        // Formulaire déjà vide
        JOptionPane.showMessageDialog(this,
            "Le formulaire est déjà vide",
            "Information",
            JOptionPane.INFORMATION_MESSAGE);
    }
   //vente frame 
    clearForm();
    }//GEN-LAST:event_btnVider1ActionPerformed

    private void btnRetour1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetour1ActionPerformed
    MainFrame mf = new MainFrame();
    mf.setVisible(true);      
    this.dispose();

    }//GEN-LAST:event_btnRetour1ActionPerformed

    private void tableVentesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableVentesMouseClicked
   

    int selectedRow = tableVentes.getSelectedRow();

    if (selectedRow != -1) {

        txtIdVente.setText(tableVentes.getValueAt(selectedRow, 0).toString());
        txtDateVente.setText(tableVentes.getValueAt(selectedRow, 1).toString());

        // Pour Client et Produit (si tu utilises format "id - nom")
        int idClient = Integer.parseInt(tableVentes.getValueAt(selectedRow, 2).toString());
        int idProduit = Integer.parseInt(tableVentes.getValueAt(selectedRow, 3).toString());

        selectComboById(ComboClient, idClient);
        selectComboById(ComboProduit, idProduit);

        txtQuantite.setText(tableVentes.getValueAt(selectedRow, 4).toString());
    }
    }//GEN-LAST:event_tableVentesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VenteFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VenteFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VenteFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VenteFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VenteFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox ComboClient;
    private javax.swing.JComboBox ComboProduit;
    private javax.swing.JButton btnRetour1;
    private javax.swing.JButton btnSupprimer1;
    private javax.swing.JButton btnVendre1;
    private javax.swing.JButton btnVider1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblClient1;
    private javax.swing.JLabel lblIdVente1;
    private javax.swing.JLabel lblProduit1;
    private javax.swing.JLabel lblQuantite1;
    private javax.swing.JPanel panelSuivi;
    private javax.swing.JTabbedPane panelVentes;
    private javax.swing.JTable tableSuivi;
    private javax.swing.JTable tableVentes;
    private javax.swing.JTextField txtDateVente;
    private javax.swing.JTextField txtIdVente;
    private javax.swing.JTextField txtQuantite;
    // End of variables declaration//GEN-END:variables

    private void selectComboById(JComboBox combo, int id) {
    for (int i = 0; i < combo.getItemCount(); i++) {
        String item = combo.getItemAt(i).toString(); // "id - nom"
        int itemId = Integer.parseInt(item.split(" - ")[0].trim());
        if (itemId == id) {
            combo.setSelectedIndex(i);
            return;
        }
    }
}

private void clearForm() {
    txtIdVente.setText("");
    txtDateVente.setText("");
    txtQuantite.setText("");

    if (ComboClient.getItemCount() > 0) ComboClient.setSelectedIndex(0);
    if (ComboProduit.getItemCount() > 0) ComboProduit.setSelectedIndex(0);
}
}
