package boutique.dao;

import boutique.entities.Client;

public interface IClientDao extends IDao<Client> {
}
