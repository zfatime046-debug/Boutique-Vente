package boutique.dao;
import boutique.entities.Produit;

import java.util.List;

public class TestProduitDao {

    public static void main(String[] args) {

        ProduitDao dao = new ProduitDao();

        // 1) CREATE
        Produit p = new Produit();
        p.setLibelle("Souris");
        p.setPrix(50.0);
        p.setCategorie("Informatique");
        p.setStock(30);

        dao.create(p);
        System.out.println("Produit ajouté avec id = " + p.getIdProduit());

        // 2) FIND ALL
        List<Produit> produits = dao.findAll();
        System.out.println("---- Liste produits ----");
        for (Produit pr : produits) {
            System.out.println(pr);
        }

        // 3) FIND BY ID
        Produit p2 = dao.findById(p.getIdProduit());
        System.out.println("---- Produit trouvé ----");
        System.out.println(p2);

        // 4) UPDATE
        if (p2 != null) {
            p2.setStock(p2.getStock() + 10);
            dao.update(p2);
            System.out.println("Stock modifié !");
        }

        // 5) DELETE (décommente si tu veux supprimer)
        // dao.delete(p.getIdProduit());
        // System.out.println("Produit supprimé !");
    }
}
