package boutique.dao;

import boutique.entities.Client;
import boutique.entities.Produit;
import boutique.entities.Vente;

import java.sql.Date;
import java.util.List;

public class TestCrudAll {

    public static void main(String[] args) {

        ProduitDao produitDao = new ProduitDao();
        ClientDao clientDao = new ClientDao();
        VenteDao venteDao = new VenteDao();

        System.out.println("===== TEST PRODUIT =====");

        // 1) CREATE PRODUIT
        Produit p = new Produit();
        p.setLibelle("laptop");
        p.setPrix(120.0);
        p.setCategorie("Informatique");
        p.setStock(5);

        produitDao.create(p);
        System.out.println("Produit ajouté id = " + p.getIdProduit());

        // 2) FIND BY ID
        Produit p2 = produitDao.findById(p.getIdProduit());
        System.out.println("Produit trouvé : " + p2);

        // 3) UPDATE
        p2.setStock(p2.getStock() + 10);
        produitDao.update(p2);
        System.out.println("Produit stock modifié");

        // 4) FIND ALL
        List<Produit> produits = produitDao.findAll();
        System.out.println("Liste produits (" + produits.size() + ")");
        for (Produit pr : produits) System.out.println(pr);

        System.out.println("\n===== TEST CLIENT =====");

        // 1) CREATE CLIENT (email unique)
        Client c = new Client();
        c.setNom("ikram");
        c.setVille("Rabat");
        c.setEmail("ikram" + System.currentTimeMillis() + "@gmail.com"); // 

        clientDao.create(c);
        System.out.println("Client ajouté id = " + c.getIdClient());

        // 2) FIND BY ID
        Client c2 = clientDao.findById(c.getIdClient());
        System.out.println("Client trouvé : " + c2);

        // 3) UPDATE
        c2.setVille("ouajda");
        clientDao.update(c2);
        System.out.println("Client modifié");

        // 4) FIND ALL
        List<Client> clients = clientDao.findAll();
        System.out.println("Liste clients (" + clients.size() + ")");
        for (Client cl : clients) System.out.println(cl);

        System.out.println("\n===== TEST VENTE (avec stock) =====");

        // ⚠️ Vente avec le produit qu’on vient d’ajouter (p2)
        Vente v = new Vente();
        v.setDateVente(Date.valueOf("2026-02-18"));
        v.setIdProduit(p2.getIdProduit());
        v.setIdClient(c2.getIdClient());
        v.setQuantite(3);

        venteDao.create(v);
        System.out.println("Vente ajoutée id = " + v.getIdVente());

        // Vérifier stock diminué
        Produit pAfter = produitDao.findById(p2.getIdProduit());
        System.out.println("Stock après vente = " + pAfter.getStock() + " ✅");

        // FIND ALL ventes
        List<Vente> ventes = venteDao.findAll();
        System.out.println("Liste ventes (" + ventes.size() + ")");
        for (Vente ve : ventes) System.out.println(ve);

        System.out.println("\n===== TEST ERREUR: Stock insuffisant =====");
        try {
            Vente vErr = new Vente();
            vErr.setDateVente(Date.valueOf("2026-02-18"));
            vErr.setIdProduit(p2.getIdProduit());
            vErr.setIdClient(c2.getIdClient());
            vErr.setQuantite(9999); 

            venteDao.create(vErr);
        } catch (Exception e) {
            System.out.println("Erreur attendue : " + e.getMessage());
        }
    }
}
