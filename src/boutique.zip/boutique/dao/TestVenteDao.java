package boutique.dao;

import boutique.entities.Vente;
import java.sql.Date;

public class TestVenteDao {
    public static void main(String[] args) {

        VenteDao dao = new VenteDao();

        Vente v = new Vente();
        v.setDateVente(Date.valueOf("2026-02-18"));
        v.setIdProduit(1);
        v.setIdClient(1);  
        v.setQuantite(2);

        dao.create(v);

        System.out.println("Vente ajoutée avec id = " + v.getIdVente());
    }
}
