package boutique.dao;

import boutique.entities.Vente;
import java.util.List;

public interface IVenteDao extends IDao<Vente> {
    List<Object[]> venteParProduit();
}
