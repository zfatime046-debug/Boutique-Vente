package boutique.dao;

import boutique.entities.Produit;

public interface IProduitDao extends IDao<Produit> {
}
