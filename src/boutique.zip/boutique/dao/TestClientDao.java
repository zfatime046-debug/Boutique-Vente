package boutique.dao;

import boutique.entities.Client;

import java.util.List;

public class TestClientDao {

    public static void main(String[] args) {

        ClientDao dao = new ClientDao();

        // 1) CREATE
        Client c = new Client();
        c.setNom("zaha");
        c.setVille("Rabat");
        c.setEmail("zaha@gmail.com");

        dao.create(c);
        System.out.println("Client ajouté avec id = " + c.getIdClient());

        // 2) FIND ALL
        List<Client> clients = dao.findAll();
        System.out.println("---- Liste clients ----");
        for (Client cl : clients) {
            System.out.println(cl);
        }

        // 3) FIND BY ID
        Client c2 = dao.findById(c.getIdClient());
        System.out.println("---- Client trouvé ----");
        System.out.println(c2);

        // 4) UPDATE
        if (c2 != null) {
            c2.setVille("Casablanca");
            dao.update(c2);
            System.out.println("Client modifié !");
        }

        // 5) DELETE (décommente si tu veux supprimer)
        // dao.delete(c.getIdClient());
        // System.out.println("Client supprimé !");
    }
}
